.. _pred_package_algo_base:

The algorithm base class
------------------------

.. automodule:: surprise.prediction_algorithms.algo_base
    :members:
