.. _accuracy:

accuracy module
===================


.. automodule:: surprise.accuracy
    :members:
    :undoc-members:
    :show-inheritance:
